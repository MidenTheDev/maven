package us.to.midensthings.nouveauEnchanting;

import io.papermc.paper.plugin.lifecycle.event.types.LifecycleEvents;
import io.papermc.paper.registry.RegistryAccess;
import io.papermc.paper.registry.RegistryKey;
import org.bukkit.*;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import us.to.midensthings.nouveauEnchanting.addons.AddonLoader;
import us.to.midensthings.nouveauEnchanting.addons.CustomEnchantmentRegistry;
import us.to.midensthings.nouveauEnchanting.commands.Debug;
import us.to.midensthings.nouveauEnchanting.commands.EnchantCommands;
import us.to.midensthings.nouveauEnchanting.commands.Enchanting;
import us.to.midensthings.nouveauEnchanting.enchanting.MaterialRegistry;
import us.to.midensthings.nouveauEnchanting.events.EnchantEventBridge;
import us.to.midensthings.nouveauEnchanting.events.InventoryClick;
import us.to.midensthings.nouveauEnchanting.events.InventoryClose;
import us.to.midensthings.nouveauEnchanting.events.OpenEnchantingTable;
import us.to.midensthings.nouveauEnchanting.util.UpdateTracker;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

public final class NouveauEnchanting extends JavaPlugin {

    FileConfiguration config;
    PluginManager pm;

    public YamlConfiguration materialsConf;
    public YamlConfiguration enchantsConf;

    Logger logger = this.getLogger();
    public MaterialRegistry materialRegistry;

    public List<String> enabledCompats;
    private UpdateTracker updateTracker;

    private final CustomEnchantmentRegistry customEnchantments;
    private final AddonLoader addonLoader;


    public NouveauEnchanting(MaterialRegistry bootstrapRegistry, YamlConfiguration bootMaterialsConf, YamlConfiguration bootEnchantsConf,
                             CustomEnchantmentRegistry bootCustomEnchantments, AddonLoader bootAddonLoader) {
        materialRegistry = bootstrapRegistry;
        materialsConf = bootMaterialsConf;
        enchantsConf = bootEnchantsConf;
        customEnchantments = bootCustomEnchantments;
        addonLoader = bootAddonLoader;
    }


    @Override
    public void onEnable() {
        logger.info("Starting Nouveau Enchanting");
        pm = Bukkit.getServer().getPluginManager();

        loadConfigs();
        loadCompats();
        registerEvents();
        registerCommands();

        // Addons are loaded while bootstrapping, but can only use other plugins once they're enabled
        addonLoader.enableAddons(this);

        warnUnknownEnchants();

        if (getConfig().getBoolean("check-for-updates")) {
            this.updateTracker = new UpdateTracker();
            updateTracker.checkForUpdates();
        }

    }
    @Override
    public void onDisable() {
        logger.info("Disabling Nouveau Enchanting");
        addonLoader.disableAddons();
    }


    public void registerEvents() {
        if (config.getBoolean("override-enchanting-table")){
            pm.registerEvents(new OpenEnchantingTable(),this);
        }
        pm.registerEvents(new InventoryClick(), this);
        pm.registerEvents(new InventoryClose(), this);
        // Calls ItemEnchantEvent and ItemDisenchantEvent for vanilla enchanting tables, anvils and grindstones
        pm.registerEvents(new EnchantEventBridge(), this);
    }

    public void registerCommands() {
        this.getLifecycleManager().registerEventHandler(LifecycleEvents.COMMANDS, commands -> {
            Debug debugCmd = new Debug();
            commands.registrar().register(debugCmd.debugRootBuilder);
            Enchanting enchCmd = new Enchanting();
            commands.registrar().register(enchCmd.coreCommandBuilder);

            // Replace /enchant with a version that works with custom enchants and calls the enchant events
            if (getConfig().getBoolean("replace-enchant-command")) {
                Set<String> labels = commands.registrar().register(EnchantCommands.vanillaStyleEnchant("enchant").build(),
                        "Enchants the item the target players are holding, including custom enchants", List.of());
                if (!labels.contains("enchant")) {
                    logger.warning("Couldn't replace /enchant because another plugin already uses it. Nouveau Enchanting's version can be used as /"
                            + String.join(" or /", labels));
                }
            }
        });

    }


    public void loadCompats() {
        enabledCompats = new ArrayList<>();
        if (pm.getPlugin("ItemsAdder") != null) {
            enabledCompats.add("ItemsAdder");
            logger.info("ItemsAdder Compatibility Enabled");
        }
        if (pm.getPlugin("CraftEngine") != null) {
            enabledCompats.add("CraftEngine");
            logger.info("CraftEngine Compatibility Enabled");
        }
        if (pm.getPlugin("ServerLevels") != null) {
            enabledCompats.add("ServerLevels");
            logger.info("ServerLevels Compatibility Enabled");
        }

    }

    public void loadConfigs() {
        // make configs
        saveDefaultConfig();
        config = this.getConfig();

        // Warn if the config on disk was made for a different version of the plugin
        Configuration defaults = config.getDefaults();
        if (defaults != null && !String.valueOf(defaults.getString("config-version")).equals(config.getString("config-version"))) {
            logger.warning("config.yml has config-version " + config.getString("config-version") + " but this version of the plugin expects " + defaults.getString("config-version") + ". Missing options will use their defaults.");
        }

    }

    /***
     * Warns about enchants in enchants.yml that don't exist, e.g. typos or enchants from addons and datapacks that were removed.
     * Their settings can't be applied to anything, so they're ignored.
     * The enchant registry is complete by now, so this also sees enchants added by datapacks.
     */
    private void warnUnknownEnchants() {
        Registry<Enchantment> enchantmentRegistry = RegistryAccess.registryAccess().getRegistry(RegistryKey.ENCHANTMENT);
        for (String enchant : enchantsConf.getKeys(false)) {
            NamespacedKey key = NamespacedKey.fromString(enchant);
            // Invalid keys were already warned about while bootstrapping, and custom enchants are always known
            if (key == null || customEnchantments.contains(key)) {
                continue;
            }
            if (enchantmentRegistry.get(key) == null) {
                logger.warning("enchants.yml has settings for " + enchant + ", but there's no enchant with that key, so they're ignored. "
                        + "If it's from an addon or datapack that was removed, its section can be deleted.");
            }
        }
    }

    public CustomEnchantmentRegistry getCustomEnchantments() {
        return customEnchantments;
    }

    public AddonLoader getAddonLoader() {
        return addonLoader;
    }

    public UpdateTracker getUpdateTracker() {
        return updateTracker;
    }

}
